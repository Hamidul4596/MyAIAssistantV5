# My AI Assistant V4 — Phone-first Android Agent

V4 is designed for a user who may have no PC. The Android app is the main client; the AI backend stays server-side so the OpenAI API key is never placed in the APK.

## V4 goals
- Bengali + English voice input
- AI chat/agent core
- App opening
- Web search / URL opening
- Confirmation gate for sensitive actions
- Kill switch
- Conversation context
- Screenshot analysis endpoint
- Cloud-build-ready GitHub Actions
- Clear configuration for a real Android phone

## Important
This package is source code, not a compiled APK. A cloud build is required to produce the APK.
Do not put an OpenAI API key inside the Android app or commit it to GitHub.

## Phone-only build path
1. Create/import this project into a GitHub repository using your Android phone.
2. Open the Actions tab.
3. Run the "Build Android APK" workflow.
4. Download the generated APK artifact.
5. Install it on the phone.
6. Set the backend URL in the app configuration/build environment to a reachable HTTPS backend.

For development on a local PC, `10.0.2.2` is for the Android emulator only. A physical phone needs a reachable server URL.

## Backend
Copy backend/.env.example to .env and set OPENAI_API_KEY on the server only.
Run with Python 3.11+:
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000

## Security
- API key server-side only
- Sensitive commands require confirmation
- Kill switch blocks action execution
- Never execute arbitrary shell commands from user voice
- Production should add authentication, HTTPS, rate limiting and audit logs


## Ready-to-use build note
The Android app includes offline voice/TTS, app launching and web search without requiring a backend.
For full AI chat, set `BACKEND_BASE_URL` in `android/app/build.gradle.kts` to a deployed backend.
The GitHub Actions workflow builds `app-debug.apk` from the `android` folder.
